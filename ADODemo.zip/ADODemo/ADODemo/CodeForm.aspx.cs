﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace ADODemo
{
    public partial class CodeForm : System.Web.UI.Page
    {
        department dept = new department();
        deptDAC dac = new deptDAC();
        protected void Page_Load(object sender, EventArgs e)
        {

            List<department> dr = dac.ViewAllDeptments();
            GridView1.DataSource = dr;
            GridView1.DataBind();
           
        }

        protected void btnInsert_Click(object sender, EventArgs e)
        {
            dept.dname = txtdName.Text;
            dept.salary = int.Parse(txtSalary.Text);
            dept.place = txtPlace.Text;
            int dId = dac.AddDepartment(dept);
            
            if (dId!=0)
            {
                Response.Write(" Record Inserted..!!");
            }
        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            int id = int.Parse(txtdId.Text);
            bool b = dac.DeleteDepartment(id);
            if (b)
            {
                Response.Write(" Record deleted..!!");
            }
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            dept.dId = int.Parse(txtdId.Text);
            dept.dname = txtdName.Text;
            dept.salary = int.Parse(txtSalary.Text);
            dept.place = txtPlace.Text;
            bool u = dac.UpdateDepartment(dept);
            if (u)
            {
                Response.Write(" Record Updated..!!");
            }
            
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
             
            department de=dac.SearchdeptById(int.Parse(txtdId.Text));
            if (de!=null)
            {
                
                txtdName.Text = de.dname;
                txtSalary.Text = de.salary.ToString();
                txtPlace.Text = de.place;
            }
            else
            {
                Response.Write("Record Not Found");
            }
           
        }
    }
}