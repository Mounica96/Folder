﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace ADODemo
{
    public class deptDAC
    {
        public List<department> ViewAllDeptments()
        {
         List<department> dList = new List<department>();
         SqlConnection con = new SqlConnection();
         con.ConnectionString = "Server=.; Initial Catalog=department; User id=SA;Password=wipro@123";
            SqlCommand cmd = new SqlCommand();
         cmd.CommandText = "select * from dept";
            cmd.Connection = con;
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    department dept = new department();
                    dept.dId = int.Parse(dr["dId"].ToString());
                    dept.dname = dr["dname"].ToString();
                    dept.salary = int.Parse(dr["salary"].ToString());
                    dept.place = dr["place"].ToString();
                    dList.Add(dept);
                }
            }
            con.Close();
            return dList;
        
}
        public int AddDepartment(department dept)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Server=.; Initial Catalog=department; User id=SA;Password=wipro@123";
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "Insert into dept(dname,salary,place) values(@dn,@ds,@dp);select scope_Identity()";
           
            cmd.Parameters.AddWithValue("@dn", dept.dname);
            cmd.Parameters.AddWithValue("@ds", dept.salary);
            cmd.Parameters.AddWithValue("@dp", dept.place);
            cmd.Connection = con;
            con.Open();
            int did = int.Parse(cmd.ExecuteScalar().ToString());
            con.Close();
            return did;
        }

        public bool UpdateDepartment(department d)
        {
            bool isUpdated = false;
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Server=.; Initial Catalog=department; User id=SA;Password=wipro@123";
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "Update dept Set dname=@dn,salary=@ds,place=@dp where dId=@id";
            cmd.Parameters.AddWithValue("@id", d.dId);
            cmd.Parameters.AddWithValue("@dn",d.dname);
            cmd.Parameters.AddWithValue("@ds", d.salary);
            cmd.Parameters.AddWithValue("@dp", d.place);
            cmd.Connection = con;
            con.Open();
            int rowCount1 = cmd.ExecuteNonQuery();


            if (rowCount1 == 1)
            {
                isUpdated = true;
            }
            con.Close();
            return isUpdated;
        }
        public bool DeleteDepartment(int did)
        {
            bool isDeleted = false;
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Server=.; Initial Catalog=department; User id=SA;Password=wipro@123";
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "delete from dept where dId=@id";
            cmd.Parameters.AddWithValue("@id", did);

            cmd.Connection = con;
            con.Open();
            int rowCount = cmd.ExecuteNonQuery();
            con.Close();
            if (rowCount == 1)
            {
                isDeleted = true;
            }
            return isDeleted;
        }
        public department SearchdeptById(int did)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Server=.; Initial Catalog=department; User id=SA;Password=wipro@123";
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "select * from dept where dId=@id";
            cmd.Parameters.AddWithValue("@id", did);
            department d = new department();
            cmd.Connection = con;
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                dr.Read();
                d.dname = dr["dname"].ToString();
                d.salary = int.Parse(dr["salary"].ToString());
                d.place = dr["place"].ToString();
            }
           
            con.Close();
            return d;
        }
    }
}


