﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetManagement
{
    public class AssetTracking
    {
        const string ConnectionString = "Data Source=.;Initial Catalog=AssetManagement;User ID=sa;Password=wipro@123";
        public bool AddAsset(Asset obj)
        {
            bool isAdded = false;
            if (obj == null)
                return isAdded;
            else
            {
                Random rd = new Random();
               int randomNo= rd.Next(1, 1000);
                obj.SerialNo = obj.AssetType[0].ToString() + obj.AssetType[1].ToString() + randomNo.ToString();
                SqlConnection con = new SqlConnection(ConnectionString);
                SqlCommand cmd = new SqlCommand("insert into Asset(ASSETTYPE,SERIALNO,PROCUREMENTDATE,TAGGINGSTATUS) values (@at,@sn,@pd,@ts)", con);
                cmd.Parameters.AddWithValue("@at", obj.AssetType);
                cmd.Parameters.AddWithValue("sn", obj.SerialNo);
                cmd.Parameters.AddWithValue("@pd", DateTime.Now);
                cmd.Parameters.AddWithValue("@ts", "FREE POOL");
                con.Open();
                int rowCount = cmd.ExecuteNonQuery();
                con.Close();
                if (rowCount == 1)
                {
                    isAdded= true;
                }
                else
                {
                    return isAdded;
                }

                return isAdded;
            }
        }

        public bool ModifyAsset(Asset obj)
        {
            bool isUpdated = false;
            if (obj == null)
                return isUpdated;
            else
            {
                SqlConnection con = new SqlConnection(ConnectionString);
                SqlCommand cmd = new SqlCommand("update Asset set ASSETTYPE=@at,SERIALNO=@sn,PROCUREMENTDATE=@pd,TAGGINGSTATUS=@ts)", con);
                cmd.Parameters.AddWithValue("@at", obj.AssetType);
                cmd.Parameters.AddWithValue("sn", obj.SerialNo);
                cmd.Parameters.AddWithValue("@pd", obj.ProcurementDate);
                cmd.Parameters.AddWithValue("@ts", obj.TaggingStatus);
                con.Open();
                int rowCount = cmd.ExecuteNonQuery();
                con.Close();
                if (rowCount == 1)
                {
                    isUpdated = true;
                }
                else
                {
                    return isUpdated;
                }

                return isUpdated;
            }
        }

        public bool TagAsset(AssetTagging obj)
        {
            // throw new NotImplementedException();
            bool isTagged = false;
            string taggingStatus = "";
            if (obj == null)
                return isTagged;
            else
            {
                string query = "Select TAGGINGSTATUS from Asset  where ASSETID=@aid";
                SqlConnection con = new SqlConnection(ConnectionString);
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@aid", obj.AssetID);
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        taggingStatus = dr["TAGGINGSTATUS"].ToString().ToUpper();

                        if (taggingStatus == "FREE POOL")
                        {
                            SqlConnection con1 = new SqlConnection(ConnectionString);
                            SqlCommand cmd1 = new SqlCommand("Insert into AssetTagging(EMPLOYEEID,ASSETID,TAGGINGDATE,RELEASEDATE) values(@eid,@aid,@td,null)", con1);
                            cmd1.Parameters.AddWithValue("@eid", obj.EmployeeID);
                            cmd1.Parameters.AddWithValue("@aid", obj.AssetID);
                            cmd1.Parameters.AddWithValue("@td", obj.TaggingDate);
                            // cmd1.Parameters.AddWithValue("@rd", obj.ReleaseDate);
                            con1.Open();
                            int rc = cmd1.ExecuteNonQuery();
                            con1.Close();
                            if (rc > 0)
                            {
                                SqlConnection con2 = new SqlConnection(ConnectionString);
                                SqlCommand cmd2 = new SqlCommand("Update Asset set TAGGINGSTATUS=@ts where ASSETID=@aid", con2);
                                cmd2.Parameters.AddWithValue("@ts", "tagged");
                                                cmd2.Parameters.AddWithValue("@aid", obj.AssetID);

                                con2.Open();
                                int r=cmd2.ExecuteNonQuery();
                                con2.Close();
                                if (r > 0)
                                {
                                    isTagged = true;
                                }

                            }
                            
                        }
                       
                    }
                }
               
                con.Close();
                return isTagged;
            }
         }
          
        
        public bool DeTagAsset(int intAssetId)
        {
            //  throw new NotImplementedException();

            if (intAssetId == 0)
                return false;
            else {
                SqlConnection con = new SqlConnection(ConnectionString);
                SqlCommand cmd = new SqlCommand("Update Asset set TAGGINGSTATUS='free pool' where  ASSETTID=@aid", con);
                cmd.Parameters.AddWithValue("@aid", intAssetId);
                
                SqlConnection con1 = new SqlConnection(ConnectionString);
                SqlCommand cmd1 = new SqlCommand("Update AssetTagging set RELEASEDATE=@rd where ASSETTID=@aid ");
                cmd1.Parameters.AddWithValue("@aid", intAssetId);
                cmd1.Parameters.AddWithValue("@rd", DateTime.Now);


                return true;
            }
        }
    }
}
