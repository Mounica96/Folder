﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeManagement
{
    public class Employee:Person
    {
        //TODO: Write your code here.
        public string Qualification;
        public double experience;
        public string userId;
        public string password;

        public Employee(string FirstName, string LastName, int BirthYear, int BirthMonth, int BirthDay, string Qualification, double Experience)  
        {
            this.FirstName = FirstName;
            this.LastName = LastName;
            this.BirthYear = BirthYear;
            this.BirthMonth = BirthMonth;
            this.BirthDay = BirthDay;
            this.Qualification = Qualification;
            this.experience = Experience;
        }
        
    }
}
