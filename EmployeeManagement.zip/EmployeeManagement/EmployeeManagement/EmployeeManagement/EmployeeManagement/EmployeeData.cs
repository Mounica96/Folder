﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeManagement
{
    public class EmployeeData
    {
        //TODO : Write your code here.
        List<Employee> EmployeeList { get; set; }
        public EmployeeData()
        {
            // TODO: Write your code here.
            EmployeeList = new List<Employee>();
        }
        public string AddEmployee(Employee obj)
        {
            // throw new NotImplementedException();

            if (obj == null)
            {
                return null;
            }
            else
            {
                Utility.EmployeeUtility objUtility = new Utility.EmployeeUtility();
                objUtility.GenerateUserName(obj, 1);
                EmployeeList.Add(obj);
                return obj.userId;

            }

        }

        public bool ModifyEmployee(Employee obj)
        {
            bool isModified = false;
            if (obj == null)
                return isModified;
            else
            {
                for (int i = 0; i <EmployeeList.Count() ; i++)
                {
                   if( EmployeeList[i].userId == obj.userId)
                    isModified = true;
                }
                return isModified;
            }
        }

        public Employee SearchEmployee(string strUserID)
        {
            Employee e = null;
            //throw new NotImplementedException();
            if (string.IsNullOrEmpty(strUserID))
                return e;
            else
            {
                for (int i = 0; i < EmployeeList.Count; i++)
                {
                    if (EmployeeList[i].userId == strUserID)
                    {
                       e = EmployeeList[i];
                    }
                }
                return e;

            }
        }

        public bool DeleteEmployee(string strUserID)
        {
            bool isDeleted = false;
            if (string.IsNullOrEmpty(strUserID))
                return isDeleted;
            else
            {
                for (int i = 0; i < EmployeeList.Count; i++)
                {
                    if (EmployeeList[i].userId == strUserID)
                    {
                        EmployeeList.RemoveAt(Convert.ToInt32(EmployeeList[i].userId));
                        isDeleted = true;
                    }
                }
                return isDeleted;
            }
        }
    }
}
