﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeManagement.Utility
{
    public class EmployeeUtility
    {
        public void GenerateUserName(Employee obj,int EmployeeCount)
        {
            string str = ((char)(obj.FirstName[0]+obj.FirstName.Length)).ToString()+ ((char)(obj.LastName[0] + obj.LastName.Length)).ToString();
            //char[] ch1 = obj.FirstName.ToCharArray();
            //char[] ch2 = obj.LastName.ToCharArray();
            //char f = ch1[0];
            //char l = ch2[0];
            //int l1 = obj.FirstName.Length;
            //int l2 = obj.LastName.Length;
            //char first= Convert.ToChar(f + l1);
            //char last = Convert.ToChar(l + l2);
            //string uname = Convert.ToString(first + last);
            //string d = SumDigits(obj.BirthDay);
            //string m = SumDigits(obj.BirthMonth);
            //string y = SumDigits(obj.BirthYear);
            //string c = Convert.ToString(EmployeeCount);
            //obj.userId = uname+  y + m + d+c;
            //Console.WriteLine(userId);

            str += SumDigits(obj.BirthYear) + SumDigits(obj.BirthMonth) + SumDigits(obj.BirthDay);
           str += EmployeeCount;
            obj.userId = str;

            
        }

        public string SumDigits(int value)
        {
            string str;
            int sum = 0;
            while (value > 0)
            {
                int rem = value % 10;
                sum = sum + rem;
                value = value / 10;
            }
            str = Convert.ToString(sum);
           // throw new NotImplementedException();
            return str;
        }
    }
}
