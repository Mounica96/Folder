﻿using System;


namespace MovieTicketing
{
    public class Movies
    {
        //TODO: Write Code here               
    }
}
