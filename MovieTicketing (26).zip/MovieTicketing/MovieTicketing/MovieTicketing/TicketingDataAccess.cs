﻿using System;


namespace MovieTicketing
{
    public class TicketingDataAccess
    {
        string ConnectionString = "Data Source=.;Initial Catalog=MovieTicketing;User ID=sa;Password=wipro@123";

        public bool AddMovie(Movies obj)
        {
            throw new NotImplementedException();
        }

        public bool AddTheatre(Theatres obj)
        {
            throw new NotImplementedException();
        }

        public bool AddShow(Shows obj)
        {
            throw new NotImplementedException();
        }

        public string AddTicket(Tickets obj)
        {
            throw new NotImplementedException();
        }


        public int DeleteMovie(int intMovieID)
        {
            throw new NotImplementedException();
        }
    }
}
