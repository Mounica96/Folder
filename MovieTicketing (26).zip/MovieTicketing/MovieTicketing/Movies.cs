﻿using System;


namespace MovieTicketing
{
    public class Movies
    {
        //TODO: Write Code here   
        public int MovieID { get; set; }
        public string MovieName { get; set; }
        public string DirectorName { get; set; }
        public int PlaysPerDay { get; set; }
        public decimal TicketPrice { get; set; }
    }
}
