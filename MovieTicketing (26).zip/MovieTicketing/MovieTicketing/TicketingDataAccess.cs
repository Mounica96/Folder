﻿using System;
using System.Data.SqlClient;


namespace MovieTicketing
{
    public class TicketingDataAccess
    {
        string ConnectionString = "Data Source=.;Initial Catalog=MovieTicketing;User ID=sa;Password=wipro@123";

        public bool AddMovie(Movies obj)
        {
            //throw new NotImplementedException();
            bool isAdded = false;
            if (obj == null)
            {

                return isAdded;
            }
            else
            {
                SqlConnection con = new SqlConnection();
                con.ConnectionString = ConnectionString;
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "insert into Movies(Director,MovieName,PlaysPerDay,TicketPrice) values(@Director,@mn,@PlaysPerDay,@TicketPrice)";
                cmd.Parameters.AddWithValue("@Director", obj.DirectorName);
                cmd.Parameters.AddWithValue("@mn", obj.MovieName);
                cmd.Parameters.AddWithValue("@PlaysPerDay", obj.PlaysPerDay);
                cmd.Parameters.AddWithValue("@TicketPrice", obj.TicketPrice);
                cmd.Connection = con;
                con.Open();
                int rowCount = cmd.ExecuteNonQuery();
                con.Close();
                if (rowCount == 1)
                {
                    isAdded = true;
                }
                return isAdded;
            }
        }

        public bool AddTheatre(Theatres obj)
        {
            //throw new NotImplementedException();
            bool isAdded = false;
            if (obj == null)
            {
                return isAdded;
            }
            else
            {
                SqlConnection con = new SqlConnection();
                con.ConnectionString = ConnectionString;
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "insert into Theatres(TheatreName,SeatingCapacity) values(@TheatreName,@SeatingCapacity)";
                cmd.Parameters.AddWithValue("@TheatreName", obj.TheatreName);
                cmd.Parameters.AddWithValue("@SeatingCapacity", obj.SeatingCapacity);
                cmd.Connection = con;
                con.Open();
                int rowCount = cmd.ExecuteNonQuery();
                con.Close();
                if (rowCount == 1)
                {
                    isAdded = true;
                }
                return isAdded;
            }
        }

        public bool AddShow(Shows obj)
        {
            // throw new NotImplementedException();
            bool isAdded = false;
            if (obj == null)
            {
                return isAdded;
            }
            else
            {
                SqlConnection con = new SqlConnection();
                con.ConnectionString = ConnectionString;
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "insert into Theatres values(@TheatreID,@MovieID,@StartDate,@EndDate,@StartTime,@EndTime)";
                cmd.Parameters.AddWithValue("@TheatreID", obj.TheatreID);
                cmd.Parameters.AddWithValue("@MovieID", obj.MovieID);
                cmd.Parameters.AddWithValue("@StartDate", obj.StartDate);
                cmd.Parameters.AddWithValue("@EndDate", obj.EndDate);
                cmd.Parameters.AddWithValue("@StartTime", obj.StartTime);
                cmd.Parameters.AddWithValue("@EndTime", obj.EndTime);
                cmd.Connection = con;
                con.Open();
                int rowCount = cmd.ExecuteNonQuery();
                con.Close();
                if (rowCount == 1)
                {
                    isAdded = true;
                }
                return isAdded;
            }
        }

        public string AddTicket(Tickets obj)
        {

            string str = null;
            if (obj != null)
            {
                string movieName = "";
                decimal ticketPrice = 0;
                string query = "select m.MovieName,m.TicketPrice from Movies m join Shows s on m.MovieID=s.MovieId join Tickets t on s.ShowID=t.ShowID where t.ShowID=@sid";
                SqlConnection con = new SqlConnection(ConnectionString);
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@sid", obj.ShowID);

                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    dr.Read();
                    movieName = dr["MovieName"].ToString();
                    ticketPrice = decimal.Parse(dr["TicketPrice"].ToString());
                }
                con.Close();
                Random rd = new Random();
                int rand = rd.Next(1, 1000);
                str = (obj.CustomerName[0] + obj.CustomerName[1]).ToString() + ((obj.NumberofPersons).ToString()) + (movieName[0] + movieName[1]).ToString() + (obj.BookingDate.Day).ToString() + (obj.BookingDate.Month).ToString() + rand.ToString();

                obj.ReferenceCode = str.ToUpper();
                //obj.Amount = obj.NumberofPersons * ticketPrice;
                SqlConnection con1 = new SqlConnection(ConnectionString);
                SqlCommand cmd1 = new SqlCommand();
                cmd1.CommandText = "insert into Tickets(ShowID,CustomerName,ReferenceCode,BookingDate,NumberofPersons,Amount,TicketStatus) values(@sid1,@cn,@rc, @bkd,@amt,@nop,@ts)";
                cmd1.Parameters.AddWithValue("@sid1", obj.ShowID);
                cmd1.Parameters.AddWithValue("@cn", obj.CustomerName);
                cmd1.Parameters.AddWithValue("@rc", obj.ReferenceCode);
                cmd1.Parameters.AddWithValue("@bkd", obj.BookingDate);
                cmd1.Parameters.AddWithValue("@nop", obj.NumberofPersons);
                cmd1.Parameters.AddWithValue("@amt", obj.Amount);
                cmd1.Parameters.AddWithValue("@ts", obj.TicketStatus);
                cmd1.Connection = con1;
                con1.Open();
                int rowCount = cmd1.ExecuteNonQuery();
                con1.Close();
                if (rowCount == 1)
                {
                    return obj.ReferenceCode;
                }

                else
                {
                    return null;
                }

            }



            else
            {
                return null;
            }

        }





        public int DeleteMovie(int intMovieID)
        {
            int rowsDeleted = 0;
            if (intMovieID == 0)
            {
                return 0;

            }
            else
            {
                SqlConnection con = new SqlConnection(ConnectionString);
                SqlCommand cmd = new SqlCommand("select ShowID from Shows where MovieID=@mid", con);
                cmd.Parameters.AddWithValue("@mid", intMovieID);
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        int showID = int.Parse(dr["ShowID"].ToString());
                        SqlConnection con1 = new SqlConnection(ConnectionString);
                        SqlCommand cmd1 = new SqlCommand("delete from Tickets where ShowID =@sid", con1);
                        cmd1.Parameters.AddWithValue("@sid", showID);
                        con1.Open();
                        int rows = cmd1.ExecuteNonQuery();
                        rowsDeleted += rows;
                        con1.Close();
                        if (rowsDeleted > 0)
                        {
                            SqlConnection con2 = new SqlConnection(ConnectionString);
                            SqlCommand cmd3 = new SqlCommand("delete from Shows where MovieID =@mid", con2);
                            cmd3.Parameters.AddWithValue("@mid", intMovieID);
                            con2.Open();
                            int row_num = cmd3.ExecuteNonQuery();
                            rowsDeleted += row_num;
                            con2.Close();
                            if (row_num > 0)
                            {
                                SqlConnection con3 = new SqlConnection(ConnectionString);
                                SqlCommand cmd4 = new SqlCommand("delete from Movies where MovieID =@mid", con3);
                                cmd4.Parameters.AddWithValue("@mid", intMovieID);
                                con3.Open();
                                int rownum = cmd4.ExecuteNonQuery();
                                rowsDeleted += rownum;
                                con3.Close();
                                return rowsDeleted;
                            }
                            else
                            {
                                return 0;

                            }

                        }
                        else
                        {
                            return 0;

                        }
                    }
                    con.Close();


                    return rowsDeleted;
                }
                else
                {
                    return 0;
                }


                //    return rowsDeleted;


            }
        }
    }
}

