﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StatisticsOfWord
{
    class Program
    {
        static void Main(string[] args)
        {
            int dig = 0,c=0,d=0;
            string alp = "";
            string input1 = "12B3A4NGLORE";
            char[] ch = input1.ToCharArray();
            for(int i = 0; i < ch.Length; i++)
            {
                if (Char.IsDigit(ch[i]))
                {
                    dig = dig + int.Parse(ch[i].ToString());
                    d++
                }
                else
                {
                    alp = alp + ch[i];
                    c++;
                }
            }
            string result = c.ToString() + alp + dig.ToString();
            if (d == 0 || c == 0 || dig == 0)
            {
                result = "zero";
            }
            else
            {
                result = c.ToString() + alp + dig.ToString();
            }
            return result;
        }
    }
}
