﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringProgram
{
    class Program
    {
        static void Main(string[] args)
        {
            string x="", y="",p="",q="";
            string str="This is a nice day";
            string[] st1 = str.Split(' ');
            int num1 = 4, num2 = 1;
            string s1 = st1[num1-1];
            string s2 = st1[num2-1];
            int l1 = s1.Length;
            //Console.WriteLine(  l1);
            int l2 = s2.Length;
          bool b1 =  IsEven(l1);
            bool b2 = IsEven(l2);
            if (b1)
            {
                 x = s1.Substring(0,(l1/2));
                p = s1.Substring((l1 / 2) );
            }
            else
            {
                x = s1.Substring(0, (l1 / 2)+1);
                p = s1.Substring((l1 / 2) + 2);
            }
            if (b2)
            {
                y = s2.Substring(0, (l2 / 2));
               q = s2.Substring((l2 / 2) );
            }
            else
            {
                y = s2.Substring(0, (l2 / 2) + 1);
               q = s2.Substring((l2 / 2));

            }
            //Console.WriteLine(x);
            //Console.WriteLine(p);

            //Console.WriteLine(y);
            //Console.WriteLine(q);


            char[] ch = x.ToCharArray();
            Array.Reverse(ch);
            String a = new string(ch);
            char[] ch1 = y.ToCharArray();
            Array.Reverse(ch1);
            String b = new string(ch1);

            //Console.WriteLine(a);
            //Console.WriteLine(b);





            string one = String.Concat(a, p);
            Console.Write(one);
            Console.Write(" ");

            string two = String.Concat(b, q);
            Console.WriteLine(two);





        }
        public static bool IsEven(int n)
        {
            if (n % 2 == 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
