﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TelephoneBilling
{
    public class BillingData
    {
        // TODO: Write your code here

        public BillingData()
        {
            // TODO: Write your code here.
        }

        public bool GenerateBill(Bill obj)
        {

            // TODO: Write your code here. 
            // Remove the below statement, "throw new NotImplementedException();" before writing your code.
            throw new NotImplementedException();
        }

        public Bill SearchBill(int intBillingID)
        {

            // TODO: Write your code here. 
            // Remove the below statement, "throw new NotImplementedException();" before writing your code.
            throw new NotImplementedException();

        }

        public bool UpdateBill(Bill obj)
        {

            // TODO: Write your code here. 
            // Remove the below statement, "throw new NotImplementedException();" before writing your code.
            throw new NotImplementedException();
        }
    }
}
