﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TelephoneBilling.Utility
{
    public class BillingUtility
    {
        public decimal CalculateBill(int intNumberOfUnits, decimal decOutstandingAmount = 0.0m)
        {

            // TODO: Write your code here. 
            // Remove the below statement, "throw new NotImplementedException();" before writing your code.
            throw new NotImplementedException();
        }
    }
}
