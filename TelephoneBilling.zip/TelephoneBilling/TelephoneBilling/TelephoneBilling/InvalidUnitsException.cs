﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TelephoneBilling.Exceptions
{
    public class InvalidUnitsException:Exception
    {
        public InvalidUnitsException(string strMessage)
        {

            // TODO: Write your code here. 
            // Remove the below statement, "throw new NotImplementedException();" before writing your code.
            throw new NotImplementedException();
        }
    }
}
