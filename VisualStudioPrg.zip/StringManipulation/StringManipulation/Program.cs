﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringManipulation
{
    class Program
    {
        static void Main(string[] args)
        {
            string str = "helloworld";
            char[] ch = str.ToArray();
            Array.Reverse(ch);
            Console.WriteLine(ch);

            string sub = str.Substring(2);
            Console.WriteLine(sub);

            string replace = str.Replace('l','$');
            Console.WriteLine(replace);

            string str2 = str;
            str2 = str2.ToUpper();

            Console.WriteLine("main string : "+str+" and modified string : "+str2);
        }
    }
}
