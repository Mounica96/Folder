﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AreaOfSqr
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter side of a square");
            int side = Convert.ToInt32(Console.ReadLine());

            int area = side * side;
            Console.WriteLine("area of a square {0}",area);


        }
    }
}
