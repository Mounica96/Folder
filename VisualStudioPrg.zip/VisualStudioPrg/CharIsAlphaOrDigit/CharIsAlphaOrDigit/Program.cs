﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CharIsAlphaOrDigit
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter a character");
            char ch=Convert.ToChar(Console.ReadLine());
            bool b = Char.IsDigit(ch);
            if (b)
            {
                Console.WriteLine("entered character "+ch +" is a digit");
            }
            else
            {
                Console.WriteLine("entered character " + ch + " is an alphabet");

            }
        }
    }
}
