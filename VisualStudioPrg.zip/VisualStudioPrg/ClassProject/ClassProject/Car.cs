﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassProject
{
    class Car
    {
        private string carmake;
        private string model;
        private int mfgyear;
        private int price;

        public Car(string cm, string mod, int year, int cost)
        {
            carmake = cm;
            model = mod;
            mfgyear = year;
            price = cost;
        }
        public void display()
        {
            Console.WriteLine("carmake : "+carmake);
            Console.WriteLine("model : " + model);
            Console.WriteLine("year of manufacturing : " + mfgyear);
            Console.WriteLine("price of the car : " + price);

        }
    }
}
