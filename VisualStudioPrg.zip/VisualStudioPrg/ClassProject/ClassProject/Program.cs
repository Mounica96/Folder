﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassProject
{
    class Program
    {
        static void Main(string[] args)
        {
            Car c = new Car("maruthi", "Mar800", 2000, 150000);
            c.display();
        }
    }
}
