﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CollectionsProgram
{
    class EmployeeCollections
    {
       
        public string empName { get; set; }
      public  int empId { get; set; }
    public  double salary{ get; set; }


    }
}
