﻿using System;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CollectionsProgram
{
    class Program
    {
        static void Main(string[] args)
        {
            //ArrayList a = new ArrayList();
            EmployeeDAL ed = new EmployeeDAL();
            EmployeeCollections objData = new EmployeeCollections();
           ed.addEmployee(new EmployeeCollections() { empId = 100, empName = "Smith",salary=20000 });
            ed.addEmployee(new EmployeeCollections() { empId = 101, empName = "John" ,salary=50000});
            ed.addEmployee(new EmployeeCollections() { empId = 102, empName = "Anu", salary = 45000 });
            ed.Display();
            ed.searchEmployee(100);
            ed.deleteEmployee(101);
            ed.getAllEmployee();
           // ed.searchEmployee(102);
           // ed.Display1();

        }
    }
}
