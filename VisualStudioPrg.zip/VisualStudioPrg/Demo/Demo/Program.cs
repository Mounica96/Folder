﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo
{
    class Program
    {
        static void Main(string[] args)
        {

            int a, b, c;
            Console.WriteLine("enter value of a :");
            a = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter value of b :");
            b = Convert.ToInt32(Console.ReadLine());

            c = a + b;

            Console.WriteLine("enter value of c is {0} ",c);
            Console.ReadKey();








        }
    }
}
