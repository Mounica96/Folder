﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeProgram
{
    class Employee
    {
        string emp_name;
        double hra;
        double basic_salary;
        double da;
        double tax;
        double gross_salary;
        double net_salary;

        public Employee(string empName,double b_sal)
        {
            emp_name = empName;
            basic_salary = b_sal;
        }
        public void calculateNetPay()
        {
            hra = (15 * basic_salary) / 100;
            da = (10 * basic_salary) / 100;
            gross_salary = (basic_salary + hra + da);
            tax = (8 * gross_salary) / 100;
            net_salary = (gross_salary - tax);
        }
        public void display()
        {
            Console.WriteLine( "------- the salary structure of "+emp_name+ " is -------");
            Console.WriteLine("basic salary of is "+basic_salary);
            Console.WriteLine("HRA : " + hra);
            Console.WriteLine("DA :  " + da);
            Console.WriteLine("Tax : " + tax);
            Console.WriteLine("Gross Salary : " + gross_salary);
            Console.WriteLine("Net Salary :  "+ basic_salary);
            


        }
    }
}
