﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceptionProgram
{
    class ExceptionExtention
    {
        int sub1, sub2, sub3;
        string sname;
        public void raiseException()
        {
            for (int i = 0; i < 2; i++)
            {
                Console.WriteLine("enter name of the student");
                sname = Console.ReadLine();
                try
                {
                    Console.WriteLine("enter the marks of three subjects");
                    sub1 = Convert.ToInt32(Console.ReadLine());
                    sub2 = Convert.ToInt32(Console.ReadLine());
                    sub3 = Convert.ToInt32(Console.ReadLine());
                }
                catch (FormatException e)
                {
                    Console.WriteLine(e.Message);
                }
                finally
                {
                    Console.WriteLine("completed");
                }





            }



        }
    }
}
