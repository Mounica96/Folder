﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace FileProgram
{
    class Program
    {
        static void Main(string[] args)
        {
            File.Create("Demo.txt");

        }
    }
}
