﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IncNoAndSwap
{
    class Program
    {
        static void Main(string[] args)
        {
            int num1 = 5;
            int num2 = ++num1;
            Console.WriteLine("num2 = "+num2);

            int num3 = num1++;
            Console.WriteLine("num3 = " + num3);

            Console.WriteLine("Before swapping");
            Console.WriteLine("num2 = "+num2+" num3 = "+num3);
            Console.WriteLine("After swapping");
            int temp = num2;
            num2 = num3;
            num3 = temp;
            Console.WriteLine("num2 = " + num2 + " num3 = " + num3);

        }
    }
}
