﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IncStringBy1
{
    class Program
    {
        static void Main(string[] args)
        {
            string str = "pqrs";
            string result = "";
            foreach(char ch in str)
            {
                Console.Write(Convert.ToChar(ch+1)) ;
            }
            Console.WriteLine(" ");
            

        }
    }
}
