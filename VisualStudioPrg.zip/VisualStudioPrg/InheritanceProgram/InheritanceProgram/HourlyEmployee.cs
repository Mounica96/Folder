﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceProgram
{
    class HourlyEmployee :Person
    {
        double hoursWorked;
        double payPerHour;


    }
}
