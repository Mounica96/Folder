﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceProgram
{
    class PermanentEmployee:employee
    {
        double hra, da, tax, netPay, totalPay;
    }
}
