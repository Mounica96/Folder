﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceProgram
{
    class Person
    {
        string firstName;
        string lastName;
        string emailId;
        DateTime dateofBirth;
        string res;

        public Person(string fName,string lName,string eId,DateTime dob)
        {
            firstName = fName;
            lastName = lName;
            emailId = eId;
           dateofBirth = dob;
        }
        public bool isAdult()
        {
            int y = dateofBirth.Year;
            if ((DateTime.Now.Year-y) >= 18)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public string sunSign()    
        {

            if (dateofBirth.Month == 12)
            {
                res= "Capricorn";
                
            }
            else if (dateofBirth.Month == 1)
            {
                res= "Aquarius";

            }
       
            else if (dateofBirth.Month == 2)
            {
                res = "Pisces";
            }
            else if (dateofBirth.Month == 03)
            {
                res = "Aries";

            }
           
            else if (dateofBirth.Month == 04)
            {
                res = "Taurus";

            }
           
            else if (dateofBirth.Month == 05)
            {
                res = "Gemini";

            }

            else if (dateofBirth.Month == 06)
            {
                res = "Cancer";

            }
            else if (dateofBirth.Month == 07)
            {
                res = "Leo";

            }           
            else if (dateofBirth.Month == 08)
            {
                res = "Virgo";

            }
            else if (dateofBirth.Month == 09)
            {
                res = "Libra";

            }
         
            else if (dateofBirth.Month == 10)
            {
                res = "Scorpio";

            }
           
            else if (dateofBirth.Month == 11)
            {
                res = "Sagittarius";
            }
           
            return res;
            }
        bool a;
        string uname;
        public bool isBirthDay()
        {
            if ((dateofBirth.Day==DateTime.Now.Day)&&(dateofBirth.Month == DateTime.Now.Month))
            {
               
                   a = true;
                
            }
            else
            {
                 a= false;
            }
            return a;
        }
        public string screenName()
        {
            uname = firstName + lastName + dateofBirth.Month;
            return uname;
        }
        public void display()
        {
            Console.WriteLine("\ndetails of employee " + firstName + " " + lastName + " : ");
            Console.WriteLine("\nemail id : " + emailId);
            Console.WriteLine("\ndate of birth" + dateofBirth);
        }


        }

    }

