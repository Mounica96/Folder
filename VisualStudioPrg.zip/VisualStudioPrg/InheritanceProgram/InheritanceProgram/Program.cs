﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceProgram
{
    class Program
    {
        static void Main(string[] args)

        {
            DateTime val = new DateTime(2012, 12, 11);
            employee e = new employee("Bhanu", "Sree", "bhanu.sree@xyz", val);
                
         bool a=   e.isAdult();
            string un=e.screenName();
            string ss=e.sunSign();
           bool b=e.isBirthDay();
            e.display();
              
            Console.WriteLine("\nAdult : " +a);
            Console.WriteLine("\nis birthday of this employee today ? : "+b);
            Console.WriteLine("\nsunsign of the employee : "+ss);
            Console.WriteLine("\nusername of the employee : "+un);
            Console.WriteLine("\n");
        }
    }
}
