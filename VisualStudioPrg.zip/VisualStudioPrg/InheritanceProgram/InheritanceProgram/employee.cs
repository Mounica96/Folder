﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceProgram
{
  class employee:Person
    {
        double salary;
        public employee(string fn, string ln, string e_id, DateTime Dob) : base( fn, ln, e_id, Dob)
        {
        }

    }
}
