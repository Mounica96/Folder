﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterestCalculator
{
    class FDaccount:IAccount
    {
        double interest_rate;
        double amount,interest;
        int no_of_days;
        int age;
     public void   calculateInterest()
        {
            try
            {
                Console.WriteLine("enter amount");
                amount = int.Parse(Console.ReadLine());

                Console.WriteLine("enter number of days");
                no_of_days = int.Parse(Console.ReadLine());
                if (amount > 10000000)
                {
                    if (no_of_days >= 7 && no_of_days <= 14)
                    {
                        interest_rate = 6.50;
                        interest = (amount * interest_rate * no_of_days) / 100;
                        Console.WriteLine("interest gained : " + interest);
                    }
                    if (no_of_days >= 15 && no_of_days <= 29)
                    {
                        interest_rate = 6.75;
                        interest = (amount * interest_rate * no_of_days) / 100;
                        Console.WriteLine("interest gained : " + interest);
                    }
                    if (no_of_days >= 30 && no_of_days < 45)
                    {
                        interest_rate = 6.75;
                        interest = (amount * interest_rate * no_of_days) / 100;
                        Console.WriteLine("interest gained : " + interest);
                    }
                    if (no_of_days >= 45 && no_of_days <= 60)
                    {
                        interest_rate = 8;
                        interest = (amount * interest_rate * no_of_days) / 100;
                        Console.WriteLine("interest gained : " + interest);
                    }
                    if (no_of_days >= 61 && no_of_days <= 184)
                    {
                        interest_rate = 8.50;
                        interest = (amount * interest_rate * no_of_days) / 100;
                        Console.WriteLine("interest gained : " + interest);
                    }
                    if (no_of_days >= 185 && no_of_days <= 365)
                    {
                        interest_rate = 10.00;
                        interest = (amount * interest_rate * no_of_days) / 100;
                        Console.WriteLine("interest gained : " + interest);
                    }
                }
                else
                {
                    Console.WriteLine("select the type of citizen");
                    Console.WriteLine("General or Senior citizen");
                    string type = Console.ReadLine();
                    if (type.Equals("general"))
                    {
                        if (no_of_days >= 7 && no_of_days <= 14)
                        {
                            interest_rate = 4.50;
                            interest = (amount * interest_rate * no_of_days) / 100;
                            Console.WriteLine("interest gained : " + interest);
                        }
                        if (no_of_days >= 15 && no_of_days <= 29)
                        {
                            interest_rate = 4.75;
                            interest = (amount * interest_rate * no_of_days) / 100;
                            Console.WriteLine("interest gained : " + interest);
                        }
                        if (no_of_days >= 30 && no_of_days < 45)
                        {
                            interest_rate = 5.50;
                            interest = (amount * interest_rate * no_of_days) / 100;
                            Console.WriteLine("interest gained : " + interest);
                        }
                        if (no_of_days >= 45 && no_of_days <= 60)
                        {
                            interest_rate = 7;
                            interest = (amount * interest_rate * no_of_days) / 100;
                            Console.WriteLine("interest gained : " + interest);
                        }
                        if (no_of_days >= 61 && no_of_days <= 184)
                        {
                            interest_rate = 7.50;
                            interest = (amount * interest_rate * no_of_days) / 100;
                            Console.WriteLine("interest gained : " + interest);
                        }
                        if (no_of_days >= 185 && no_of_days <= 365)
                        {
                            interest_rate = 8.00;
                            interest = (amount * interest_rate * no_of_days) / 100;
                            Console.WriteLine("interest gained : " + interest);
                        }
                    }
                    else if (type.Equals("senior citizen"))
                    {
                        if (no_of_days >= 7 && no_of_days <= 14)
                        {
                            interest_rate = 5.00;
                            interest = (amount * interest_rate * no_of_days) / 100;
                            Console.WriteLine("interest gained : " + interest);
                        }
                        if (no_of_days >= 15 && no_of_days <= 29)
                        {
                            interest_rate = 5.25;
                            interest = (amount * interest_rate * no_of_days) / 100;
                            Console.WriteLine("interest gained : " + interest);
                        }
                        if (no_of_days >= 30 && no_of_days < 45)
                        {
                            interest_rate = 6.00;
                            interest = (amount * interest_rate * no_of_days) / 100;
                            Console.WriteLine("interest gained : " + interest);
                        }
                        if (no_of_days >= 45 && no_of_days <= 60)
                        {
                            interest_rate = 7.50;
                            interest = (amount * interest_rate * no_of_days) / 100;
                            Console.WriteLine("interest gained : " + interest);
                        }
                        if (no_of_days >= 61 && no_of_days <= 184)
                        {
                            interest_rate = 8.00;
                            interest = (amount * interest_rate * no_of_days) / 100;
                            Console.WriteLine("interest gained : " + interest);
                        }
                        if (no_of_days >= 185 && no_of_days <= 365)
                        {
                            interest_rate = 8.50;
                            interest = (amount * interest_rate * no_of_days) / 100;
                            Console.WriteLine("interest gained : " + interest);
                        }
                    }


                }
            }
            catch (InvalidException e)
            {
                Console.WriteLine("invalid");
                Console.WriteLine(e);

            }

        }
    }
}
