﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterestCalculator
{
    interface IAccount
    {
      void    calculateInterest();
        
    }
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("   select the option  ");
            Console.WriteLine("1. Interest calculator - SB");
            Console.WriteLine("2 Interest calculator - FB");
            Console.WriteLine("3 Interest calculator -RB");
            Console.WriteLine("4 EXIT");

            int choice = int.Parse(Console.ReadLine());
            switch (choice)
            {
                case 1: Console.WriteLine("Interest calculator - SB");
                        SBaccount sb = new SBaccount();
                        sb.calculateInterest();
                        break;
                case 2: Console.WriteLine("Interest calculator - FB");
                        FDaccount fd = new FDaccount();
                        fd.calculateInterest();
                        break;
                case 3: Console.WriteLine("Interest calculator - RB");
                        RDaccount rd = new RDaccount();
                        rd.calculateInterest();
                        break;
                case 4: Console.WriteLine(" You can exit");
                        break;
            }
        }
    }
    class InvalidException : Exception
    {
      
       

    }
}
