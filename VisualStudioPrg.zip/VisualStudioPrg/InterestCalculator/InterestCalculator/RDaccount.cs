﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterestCalculator
{
    class RDaccount : IAccount
    {
        double interest_rate;
        double amount, interest;
        int no_of_months;

        public void calculateInterest()
        {
            try
            {
                Console.WriteLine("enter amount");
                amount = int.Parse(Console.ReadLine());
                if (amount < 0)
                {
                    throw new InvalidException();
                }
                Console.WriteLine("enter number of months");
                no_of_months = int.Parse(Console.ReadLine());

                Console.WriteLine("select the type of citizen");
                Console.WriteLine("General or Senior citizen");
                string type = Console.ReadLine();
                if (type.Equals("general"))
                {
                    if (no_of_months == 6)
                    {
                        interest_rate = 7.50;
                        interest = (amount * interest_rate * no_of_months) / 100;
                        Console.WriteLine("interest gained : " + interest);
                    }
                    if (no_of_months == 9)
                    {
                        interest_rate = 7.75;
                        interest = (amount * interest_rate * no_of_months) / 100;
                        Console.WriteLine("interest gained : " + interest);
                    }
                    if (no_of_months == 12)
                    {
                        interest_rate = 8.00;
                        interest = (amount * interest_rate * no_of_months) / 100;
                        Console.WriteLine("interest gained : " + interest);
                    }
                    if (no_of_months == 15)
                    {
                        interest_rate = 8.25;
                        interest = (amount * interest_rate * no_of_months) / 100;
                        Console.WriteLine("interest gained : " + interest);
                    }
                    if (no_of_months == 18)
                    {
                        interest_rate = 8.50;
                        interest = (amount * interest_rate * no_of_months) / 100;
                        Console.WriteLine("interest gained : " + interest);
                    }
                    if (no_of_months == 21)
                    {
                        interest_rate = 8.75;
                        interest = (amount * interest_rate * no_of_months) / 100;
                        Console.WriteLine("interest gained : " + interest);
                    }
                }
                else if (type.Equals("senior citizen"))
                {
                    if (no_of_months == 6)
                    {
                        interest_rate = 8.00;
                        interest = (amount * interest_rate * no_of_months) / 100;
                        Console.WriteLine("interest gained : " + interest);
                    }
                    if (no_of_months == 9)
                    {
                        interest_rate = 8.25;
                        interest = (amount * interest_rate * no_of_months) / 100;
                        Console.WriteLine("interest gained : " + interest);
                    }
                    if (no_of_months == 12)
                    {
                        interest_rate = 8.50;
                        interest = (amount * interest_rate * no_of_months) / 100;
                        Console.WriteLine("interest gained : " + interest);
                    }
                    if (no_of_months == 15)
                    {
                        interest_rate = 8.75;
                        interest = (amount * interest_rate * no_of_months) / 100;
                        Console.WriteLine("interest gained : " + interest);
                    }
                    if (no_of_months == 18)
                    {
                        interest_rate = 9.00;
                        interest = (amount * interest_rate * no_of_months) / 100;
                        Console.WriteLine("interest gained : " + interest);
                    }
                    if (no_of_months == 21)
                    {
                        interest_rate = 9.25;
                        interest = (amount * interest_rate * no_of_months) / 100;
                        Console.WriteLine("interest gained : " + interest);
                    }
                }
            }
            catch (InvalidException e)
            {
                Console.WriteLine("invalid");
                Console.WriteLine(e);

            }
        }
    }
}