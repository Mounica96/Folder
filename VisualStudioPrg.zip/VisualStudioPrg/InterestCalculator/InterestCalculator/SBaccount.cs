﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterestCalculator
{
    class SBaccount : IAccount
    {
        double interest_rate;
        double amount;
        double interest;
        public void calculateInterest()
        {
            try
            {
                Console.WriteLine("enter amount");
                amount = int.Parse(Console.ReadLine());
                if (amount < 0)
                {
                    throw new InvalidException();
                }
                Console.WriteLine("select the type of citizen");
                Console.WriteLine("normal or nri");
                string type = Console.ReadLine();
                if (type == "normal")
                {
                    interest_rate = 4;
                    interest = (amount * interest_rate) / 100;
                    Console.WriteLine("interest gained : " + interest);
                }
                else if (type == "nri")
                {
                    interest_rate = 6;

                    interest = (amount * interest_rate) / 100;
                    Console.WriteLine("interest gained : " + interest);
                }
                else
                {
                    Console.WriteLine("enter valid type");
                }



            }
            catch (InvalidException e)
            {
                Console.WriteLine("invalid");
                Console.WriteLine(e);
              
            }

        }
    }
}