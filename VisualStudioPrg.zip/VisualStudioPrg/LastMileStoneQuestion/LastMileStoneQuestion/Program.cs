﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LastMileStoneQuestion
{
    class Program
    {
        static void Main(string[] args)
        {
            int num = -4582039;
            string str = "",res="";
            if (num < 0)
            {
                str = "n";
            }
            else
            {
                str = "p";
            }
            while (num > 0)
            {
                int rem = num % 10;
                 res=res+evenOrOdd(rem);
                num = num / 10;
            }
            str = str + res;
            Console.WriteLine(res);
        }
        public static string evenOrOdd(int n)
        {
            string abc="";
            if (n % 2 == 0)
            {
                abc = "e";
            }
            else
            {
                abc = "o";
            }
            return abc;
        }
    }
}
