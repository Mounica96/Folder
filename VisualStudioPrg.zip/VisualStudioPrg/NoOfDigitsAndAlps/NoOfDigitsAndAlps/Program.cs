﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NoOfDigitsAndAlps
{
    class Program
    {
        static void Main(string[] args)
        {
            int n=0,m=0;
            string str = "pqrs98xy7z";
            foreach(char ch in str)
            {
                bool num = Char.IsDigit(ch);
                if (num)
                {
                    n++;
                    Console.WriteLine("Number " + ch);

                }
                bool alp = Char.IsLetter(ch);
                if (alp)
                {
                    m++;
                    Console.WriteLine("Alphabet " + ch);

                }

            }

            Console.WriteLine("Alphabet : " + m +" Numbers : "+n);






        }
    }
}
