﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NoOfOccurranceOfANum
{
    class Program
    {
        static void Main(string[] args)
        {
            int count = 0, num1 = 125390233,temp=num1;
            int rev;
            Console.WriteLine("enter a number ");
            int num2 = Convert.ToInt32(Console.ReadLine());
            while (num1 > 0)
            {
                rev = num1 % 10;
                if (rev == num2)
                {
                    count++;
                }
                num1 = num1 / 10;
            }
            if (count == 1)
            { 
                Console.WriteLine(num2 + " occurs " + count + " time in " + temp);
            }
            else if (count > 1)
            {
                Console.WriteLine(num2 + " occurs " + count + " times in " + temp);
            }
            else
            {
                Console.WriteLine(num2 +" doesn't occur in "+temp);
            }
        }
    }
}
