﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NumPositionCheck
{
    class Program
    {
        static void Main(string[] args)
        {
            int num1 = 2586,num2=7;
            int rev,temp=num1, i=1;
            while(num1>0)
            {
                rev = num1 % 10;
                if (rev == num2)
                {
                    if (i == 1)
                    {
                        Console.WriteLine(num2+" is present at units place of "+temp);
                    }
                    else if (i == 2)
                    {
                        Console.WriteLine(num2 + " is present at tens place of " + temp);
                    }
                    else if (i == 3)
                    {
                        Console.WriteLine(num2 + " is present at hundreds place of " + temp);
                    }
                    else if (i == 4)
                    {
                        Console.WriteLine(num2 + " is present at thousands place of " + temp);
                    }
                }
               
                
                i++;
                num1 = num1 / 10;
            }
            Console.WriteLine(num2 + " not found in " + temp);

        }
    }
}
