﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NumOfElementsInArray
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] arr = { 2,90,84,63, 3, 45, 65, 72, 98, 18, 56, 28, 36 };
            int length = 0;
            foreach(int i in arr)
            {
                length++;
            
            }
            Console.WriteLine("length of given array is : "+length);
        }
    }
}
