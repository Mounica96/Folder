﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PalindromeString
{
    class Program
    {
        static void Main(string[] args)
        {
            string str="madam";
            string rev="";
      
            for(int i=str.Length-1;i>=0;i--)
            {
               rev += str[i].ToString();
                
            }
           
            if (String.Compare(str, rev )== 0)
            {
                Console.WriteLine("Palindrome");

            }
            else
            {
                Console.WriteLine("Not Palindrome");

            }

        }
    }
}
