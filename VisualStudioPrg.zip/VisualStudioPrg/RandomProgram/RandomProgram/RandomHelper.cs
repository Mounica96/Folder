﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RandomProgram
{
    class RandomHelper
    {
      public  static int RandInt(int min,int max)
        {
            Random random = new Random();
            return random.Next(min, max);
        }
        public static double RandDouble(int min, int max)
        {
            Random random = new Random();
           //  return random.NextDouble(min, max);
            return random.NextDouble();
        }
    }
}

    