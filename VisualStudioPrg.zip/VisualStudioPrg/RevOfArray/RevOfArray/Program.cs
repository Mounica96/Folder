﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RevOfArray
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] arr = { 2, 3, 45, 72 };
          
            Console.WriteLine("original array");
            foreach (int i in arr)
            {
                Console.WriteLine(i);
            }
            Console.WriteLine("Reversed array");
            Console.WriteLine("using built-in function");
            Array.Reverse(arr);
            foreach (int i in arr)
            {
                Console.WriteLine(i);
            }

            Console.WriteLine("using loops");
            
            int temp,start = 1;
           int end = arr.Length;
            while (start < end)
            {
                temp = arr[start];
               arr[start] =arr[ end];
                arr[end] = temp;
                start++;
                end--;
                
            }
            
               
            foreach (int i in arr)
            {
                Console.WriteLine(i);
            }

        }
    }
}
