﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SeparatingAlpsAndDigitsGeneric
{
    class GenericSeparation
    {
        static void Main(string[] args)
        {

            string str = "cgf587hgyg65809";
            char[] ch = str.ToCharArray();
            List<char> alphaList = new List<char>();
            List<int> digitList = new List<int>();

            for (int i = 0; i < ch.Length; i++)
            {
                if (char.IsLetter(ch[i]))
                    {
                    alphaList.Add(ch[i]);
                }
                else if (char.IsDigit(ch[i]))
                {
                    digitList.Add(ch[i]);
                }
            }
            foreach (var item in digitList)
                Console.Write(item);
            Console.WriteLine(" ");
            foreach (var item in alphaList)
                Console.Write(item);
            Console.WriteLine(" ");

            Console.WriteLine(" ");
            Console.WriteLine("After sorting");
            Console.WriteLine(" ");

            alphaList.Sort();
            foreach (var item in alphaList)
                Console.Write(item);
            Console.WriteLine(" ");

            digitList.Sort();
            foreach (var item in digitList)
                Console.Write(item);
            Console.WriteLine(" ");

        }
    }
}
