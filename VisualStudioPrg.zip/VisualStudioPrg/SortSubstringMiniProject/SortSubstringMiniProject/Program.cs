﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SortSubstringMiniProject
{
    class Program
    {
        static void Main(string[] args)
        {
            string str = "shanker",res="";

            // arrange the characters of atring str inbetween the indexes 'n' and 'm'
            int n=1, m=5;

            // res holds substring of str inbetween 'n' and 'm' 
            res = str.Substring(n,m);
         
            //Convert substring res to char[] for sorting it
            char[] ch = res.ToArray();
            Array.Sort(ch);

            //reverse the sorted array as it is sorted in ascending order
            Array.Reverse(ch);

            //prints the ordered substring
            Console.WriteLine(ch);

            //converts char[] to string
            string s = new string(ch);

           //take stringbuilder to replace ordered substring in the main string
            StringBuilder sb = new StringBuilder(str);
            sb.Replace(res, s);
         Console.WriteLine( sb);
        }
    }
}
