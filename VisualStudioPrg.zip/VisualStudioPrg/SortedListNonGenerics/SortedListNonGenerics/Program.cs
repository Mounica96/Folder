﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SortedListNonGenerics
{
    class Program
    {
        static void Main(string[] args)
        {
            SortedListImp s1 = new SortedListImp();
            SortEmp s2 = new SortEmp();
            int choice;
            do
            {
                Console.WriteLine("select one from below");
                Console.WriteLine("1.Add employee");
                Console.WriteLine("2.display employees");
                Console.WriteLine("3.Search employee");
                Console.WriteLine("4.delete employee");

                Console.WriteLine("5.Get all employees");

                choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        s1.addEmployee(new SortEmp() { empId = 11, empName = "Bhanu" });
                        s1.addEmployee(new SortEmp() { empId = 12, empName = "Anu" });
                        s1.addEmployee(new SortEmp() { empId = 13, empName = "Surya" });
                        s1.addEmployee(new SortEmp() { empId = 14, empName = "Nidhi" });
                        s1.addEmployee(new SortEmp() { empId = 15, empName = "Azas" });
                        break;
                    case 2:
                        s1.display();
                        break;
                    case 3:
                        s1.searchEmp(13);
                       

                        break;
                    case 4:
                        s1.deleteEmployee(12);
                        break;
                    case 5:
                        s1.getAllEmp();
                        break;


                }
            } while (choice <5);
        }
    }
  
}
