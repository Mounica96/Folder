﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SortedListNonGenerics
{
    class SortEmp
    {
        public int empId { get; set; }
        public string empName{get;set;}
        
    }
}
