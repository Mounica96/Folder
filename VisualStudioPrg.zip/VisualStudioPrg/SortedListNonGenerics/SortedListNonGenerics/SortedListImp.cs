﻿using System;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SortedListNonGenerics
{
    class SortedListImp
    {
        bool bo;

        SortedList s = new SortedList();
       public bool addEmployee(SortEmp e)
        {
           
             s.Add(e.empId,e);
            if(s.Contains(e.empId))
            {
                bo = true;
            }
            Console.WriteLine("added ");
            return bo;
        }
        public bool deleteEmployee(int id)
        {
            
             foreach(DictionaryEntry d in s)
                if (((int)(d.Key)==id))
                {
                    s.Remove(id);
                    bo = true;
                    Console.WriteLine("deleted employee : "+d.Value);

                }

           

            return bo;
        }
        string str = "";
        public string searchEmp(int id)
        {
            foreach (DictionaryEntry d in s) {
                if ((int)d.Key == id)
                {
                    str =(string) d.Value;
                    Console.WriteLine("search found  ");
                }
            } 
           
            return str;
        }
        public SortEmp[] getAllEmp()
        {
           
            SortEmp[] arr = new SortEmp[s.Count];
            int i = 0;
            Console.WriteLine("All employees are : ");
            foreach(DictionaryEntry d in s)
            {
                arr[i++] = d.Value as SortEmp;
               Console.WriteLine(arr[i++]);
            }
            return arr;
        }
        public void display()
        {
            IEnumerator i = s.GetEnumerator();
            if (i.MoveNext())
            {
                SortEmp e = i.Current as SortEmp;
                Console.WriteLine(e.empId);
                Console.WriteLine(e.empName);
                Console.WriteLine(e.empId + " " + e.empName );

            }

        }
    }
}
