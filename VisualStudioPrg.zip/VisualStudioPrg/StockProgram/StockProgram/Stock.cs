﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StockProgram
{
    class Stock
    {
        string stock_name;
        string stock_symbol;
        double previousClosingPrice;
        double currentClosingPrice;
        double perChange;

        public Stock(string s_name,string s_sym,double prev_cl_price,double cur_cl_price)
        {
            stock_name = s_name;
            stock_symbol = s_sym;
            previousClosingPrice = prev_cl_price;
            currentClosingPrice = cur_cl_price;
        }
        public double getChangePercentage()
        {
             perChange = (((currentClosingPrice - previousClosingPrice) * 100) / previousClosingPrice);
            return perChange;
        }

    }
}
