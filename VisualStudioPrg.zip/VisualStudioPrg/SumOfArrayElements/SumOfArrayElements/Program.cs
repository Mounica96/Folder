﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SumOfArrayElements
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] arr = { 1, 2, 3, 5, 4 };
            Console.WriteLine("Using built-in function");
            int sum = arr.Sum();
            Console.WriteLine("sum of array elements is : "+sum);

            Console.WriteLine("Using for loop");

            int result = 0;
            for(int i = 0; i < arr.Length; i++)
            {
                result += arr[i];
            }
            Console.WriteLine("sum of array elements is : " + result);

        }
    }
}
