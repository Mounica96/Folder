﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ToUpperToLower
{
    class Program
    {
        static void Main(string[] args)
        {
            string str1 = "abcde";
            string str2 = "PQRS";

            string res1 = str1.ToUpper();


            string res2 = str2.ToLower();
            

            Console.WriteLine(str1 + " converted to uppercase : " + res1 + " and " + str2 + " converted to lowercase : " + res2);


        }
    }
}
