﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace miniProject1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter the number of test cases");
            int t = Convert.ToInt32(Console.ReadLine());
            string str;
            int n, m;
            string s ;
            for (int i = 0; i < t; i++)
            {
                Console.WriteLine("enter the string");
                str = Console.ReadLine();
                string[] st1 = str.Split(' '); 
                /*
                Console.WriteLine("enter the n and m values");
                 n = Convert.ToInt32(Console.ReadLine());
                m = Convert.ToInt32(Console.ReadLine()); */

                s = st1[0];
                n = Convert.ToInt32(st1[1]);
                m = Convert.ToInt32(st1[2]);

                char[] ch = s.ToCharArray();
                Array.Sort(ch, n, m);
                Array.Reverse(ch, n, m);
                string st = new string(ch);
                Console.WriteLine(st);
         }
        }
    }
}
