﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication1
{
    public partial class MyFirstWebApp : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void ImgBtnCalendar_Click(object sender, ImageClickEventArgs e)
        {
            if (CalendarImg.Visible)
            {
                CalendarImg.Visible = false;
            }
            else
            {
                CalendarImg.Visible = true;

            }
           

        }

        protected void CalendarImg_SelectionChanged(object sender, EventArgs e)
        {
          txtDOB.Text=CalendarImg.SelectedDate.ToShortDateString();
            CalendarImg.Visible = false;  
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            LblMessege.Text = TxtFirstName.Text + " " + TxtLastName.Text;
        }
    }
}